﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace homework
{
    class Program
    {
        static byte[] ScreenSeariazel(object _object)
        {
            byte[] bytes;
            using (var ms = new MemoryStream())
            {
                IFormatter binFormat = new BinaryFormatter();
                binFormat.Serialize(ms, _object);
                bytes = ms.ToArray();
            }
            return bytes;
        }

        static void PrintScreen(object obj)
        {
            Bitmap printscreen = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
            Graphics graphics = Graphics.FromImage(printscreen as Image);
            graphics.CopyFromScreen(0, 0, 0, 0, printscreen.Size);

            byte[] printscreenArr = ScreenSeariazel(printscreen);
            Console.WriteLine(printscreenArr.Length);
            (obj as TcpClient).GetStream().Write(printscreenArr, 0, printscreenArr.Length);
            (obj as TcpClient).Close();
        }
        static void Main(string[] args)
        {
            TcpListener server = new TcpListener(IPAddress.Parse("127.0.0.1"), 7777);
            server.Start();
            while (true)
            {
                 Console.WriteLine("Server waiting");
                TcpClient client = server.AcceptTcpClient();
                try
                {
                    Console.WriteLine(client.Client.RemoteEndPoint);
                    ThreadPool.QueueUserWorkItem(PrintScreen, client);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.WriteLine(ex.StackTrace);
                }
            }
        }
    }

}
    
